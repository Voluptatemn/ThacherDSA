package Space_Invaders;

public class Shield extends SpaceThing{

	public Shield(int x, int y, int w, int h, String imgName) {
		super(x, y, w, h, imgName);
	}

}
