package Space_Invaders;

public class Laser extends SpaceThing{

	public Laser(int x, int y, int w, int h, String imgName) {
		super(x, y, w, h, imgName);
		
	}


}
