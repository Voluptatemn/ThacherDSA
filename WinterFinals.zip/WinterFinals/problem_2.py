# There is a natural pecking order in nature. A wolf will eat a sheep, a 
# sheep will eat grass, etc. You'll be given a map in which a key is a 
# predator, and the value is a list of things it eats. You'll also be given a 
# list representing an environment. Your job is to determine how many 
# organisms will be alive at the end of the simulation. Animals will only 
# eat things directly adjacent to them. Animals have manners, so they 
# eat in turns (an animal will only eat once per turn). They will eat from 
# left to right, so the first thing in the list has a chance to eat before the 
# second thing in the list (that might mean the second thing gets eaten 
# before it ever has a chance to eat). 
# Example: map: {"wolf" : ["sheep", "mouse"], "sheep" : ["grass"]}, environment: 
# ["wolf", "sheep", "grass", "grass", "sheep", "mouse", "wolf"]
# After round 1, the leftmost wolf has eaten a sheep, the middle sheep has 
# eaten grass, and the rightmost wolf has eaten a mouse. Our environment 
# would be: ["wolf", "grass", "sheep", "wolf"]
# After the second round, it would be ["wolf", "wolf"]. The sheep ate the grass, 
# then the wolf ate the sheep. No more predator-prey pairs are left, so the 
# solution is 2.

def pecking(map, enviroment):
    cut = 10 
    j = 0
    while cut != 0:
        j += 1
        print(f'{j} time')
        cut = 0
        i = 0
        delete_list = []
        while (i < len(enviroment)):
            if i == 0:
                predator = enviroment[0]
                if predator in map:
                    for prey in map[predator]:
                        if enviroment[i+1] == prey:
                            delete_list.append(1)
                i += 1
            elif i == len(enviroment) - 1:
                predator = enviroment[i]
                if predator in map:
                    for prey in map[predator]:
                        if enviroment[i-1] == prey:
                            delete_list.append(i-1)
                i += 1
            else:
                predator = enviroment[i]
                if predator in map:
                    for prey in map[predator]:
                        if enviroment[i-1] == prey:
                            delete_list.append(i-1)
                            break
                        elif enviroment[i+1] == prey:
                            delete_list.append(i+1)
                            break
                i += 1
        cut = len(delete_list)
        for index in sorted(delete_list, reverse=True):
            del enviroment[index]
        print(enviroment)
    return enviroment

map = {"wolf" : ["sheep", "mouse"], "sheep" : ["grass"]}
environment = ["wolf", "sheep", "grass", "grass", "sheep", "mouse", "wolf"]
print(pecking(map, environment))
        
                
                
                
        
    
            
            
            
        

                            
                
                            
                        