# (Math challenge) Calculate the nth Fibonacci number, where n will be a very large number.  

def Fibonacci(num):
    if num == 1:
        return 0
    if num == 2:
        return 1
    count = 2
    previous = 0
    soln = 1 
    while (count < num):
        count += 1
        temp = previous
        previous = soln
        soln = soln + temp
    return soln 

print(Fibonacci(10))