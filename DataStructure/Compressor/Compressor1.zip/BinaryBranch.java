package Compressor;

import java.util.ArrayList;

public class BinaryBranch<T> {
    T info;
    BinaryBranch left;
    BinaryBranch right;
    boolean leaf; 

    public BinaryBranch (T info) {
        this.info = info; 
        leaf = true;
    }

    public BinaryBranch (BinaryBranch left, BinaryBranch right) {
        this.left = left;
        this.right = right; 
        leaf = false; 
    }


    public boolean hasTargetLeaf (T targert) {

        if (leaf) {
            if (info == targert) {
                return true;
            } else {
                return false; 
            }
        }

        if (left.hasTargetLeaf(targert)) { 
            return true;
        } else if (right.hasTargetLeaf(targert)) {
            return true;
        } else {
            return false; 
        }

    }

    public String TargetLeafPath (T target) {
        String code = "";


        if (!leaf) {
            if (left.hasTargetLeaf(target)) {
                code += "1"; 
                code += left.TargetLeafPath(target); 
                return code; 
            } else if (right.hasTargetLeaf(target)) {
                code += "0"; 
                code += right.TargetLeafPath(target);
                return code; 
            } 
        }
        return code; 


    }

    public boolean hasTargetLeaf (T targert, String code) {

        if (leaf) {
            if (info == targert) {
                System.out.println(code); 
                return true;
            } else {
                return false; 
            }
        }

        if (left.hasTargetLeaf(targert, code)) {
            code.concat("1");
            System.out.println(code); 
            return true;
        } else if (right.hasTargetLeaf(targert, code)) {
            code.concat("0");
            System.out.println(code); 
            return true;
        } else {
            return false; 
        }

    }

}


