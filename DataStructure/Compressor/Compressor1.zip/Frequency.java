package Compressor;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.concurrent.PriorityBlockingQueue;

import BinaryBranch; 
import javax.swing.Popup;

public class Frequency{
    
    public static void main(String[] args) throws IOException {

        HashMap<Character, Integer> map = new HashMap<Character, Integer>(); 
        String path = "ExampleTest.txt"; 
        FileReader fileReader = new FileReader(path);
        BufferedReader in = new BufferedReader(fileReader);

        while (in.ready()) {
            char in_char = (char) in.read();
            if (map.containsKey(in_char)) {
                map.put(in_char, map.get(in_char) + 1);
            } else {
                map.put(in_char, 1); 
            }
        }

        in.close();

        System.out.println(map.toString()); 

        PriorityQueue<BinaryBranch<Character>> pq = new PriorityQueue<BinaryBranch<Character>>(); 
        // PriorityQueue<Character> code_que = new PriorityQueue<Character>(); 
        for (Character i: map.keySet()) {
            // code_que.add(i, map.get(i)); 
            BinaryBranch<Character> leaf = new BinaryBranch<Character>(i);
            pq.add(leaf, map.get(i)); 
        }
        int count = 0; 
        int temp_frequency = 0;
        BinaryBranch<Character> temp = new BinaryBranch<Character>(null, null); 
        while (pq.size() != 1 || count == 1) {
            if (count == 0) {
                temp_frequency = pq.frequency(); 
                temp = pq.pop(); 
                count++;
            } else if (count == 1) {
                int frequency = pq.frequency(); 
                BinaryBranch<Character> branch = new BinaryBranch<Character>(temp, pq.pop()); 
                count = 0; 
                pq.add(branch, temp_frequency + frequency); 
            }
        }
        
        HashMap<Character, String> codes = new HashMap<Character, String>(); 
        BinaryBranch<Character> last = pq.pop();
        for (Character i: map.keySet()) {
            codes.put(i, last.TargetLeafPath(i)); 
        }

        System.out.println(codes); 

    }
}