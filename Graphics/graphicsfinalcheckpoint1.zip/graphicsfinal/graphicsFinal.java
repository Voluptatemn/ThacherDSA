package graphicsfinal;


import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;

public class graphicsFinal {
    

    // the setup of the canvas 
    final int WIDTH = 600; //canvas height
    final int HEIGHT = 700; //canvas width
    final int BUTTONHEIGHT = 40; //buttonheight for the containers and layouts
    ArrayList<shape> shapes = new ArrayList<shape>(); //a list of shapes to contain all the shapes graphed on the canvas
    String status = null;  //a string to record the current shape to draw
    Color c = null; //a color to record the current color to draw
    int width = 10; 
    int height = 10; 

    public void draw(Graphics g) { //method to draw out the shapes in the lists 


        for (int i = 0; i < shapes.size(); i++) {
            shapes.get(i).draw(g);
        }
    
    }

    public void startGraphics() {
        
        JFrame frame = new JFrame("Graphics grapher");

        frame.setSize(WIDTH, HEIGHT);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //standard initialization of the frame to work with

        JPanel container = new JPanel(); // the overall container of everything
        JPanel canvas = new JPanel() { // the canvas to present the shapes

            @Override
            public void paint(Graphics g) {

                draw(g);
            }

        };

        canvas.setPreferredSize(new Dimension(WIDTH, HEIGHT - 2 * BUTTONHEIGHT)); // setting the size of the canvas, adjust with the number of button rows

        JPanel containerButton1 = new JPanel(); // the container for the buttons for the shapes, will include rectangle, circle, line, text

        JButton rectangleButton = new JButton("Rectangle"); // the button for rectangle
        rectangleButton.addActionListener(new ActionListener() { // the actionlistener that will set the shape status string to rectangle, the cirlce actionlistener serves the same purpose

            @Override
            public void actionPerformed(ActionEvent e) {

                status = "Rectangle";
                
            }
            
        });

        JButton circleButton = new JButton("Circle"); // button for circle
        circleButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                
                status = "Circle"; 
            
            }

            
        }); 
        
        JButton line = new JButton("Line"); // button for line 
        line.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //to do 
                
            
            }

            
        }); 

        JButton polygon = new JButton("Polygon");
        polygon.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // to do
                
            }

            
        });

        JButton text = new JButton("text"); // button for text
        text.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                //to do 
                
            
            }

            
        }); 


        JPanel utilityPanel = new JPanel(); // the container for all the utility buttons, including delete, choose color, clear, undo

        JButton clear = new JButton("Clear"); // button for clearing the entire canvas
        clear.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) { // just clearing the entire canvas by reinitialize the list of shapes, all the utility button needs to repaint except for choosing color 

                shapes = new ArrayList<shape>();
                frame.getContentPane().repaint();
                
                
            }
            
        });

        JButton undo = new JButton("Undo"); // button for deleting the last shape drawn
        undo.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {

                shapes.remove(shapes.size() - 1);  // removing the last entry
                frame.getContentPane().repaint();
                
                
            }
            
        });
        
        JButton choosingColor = new JButton("Color"); // choosing the color of the shapes, using jcolorchooser
        choosingColor.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                Color initialcolor = Color.RED;    
                c = JColorChooser.showDialog(choosingColor, "Choose a color", initialcolor); 
                
            }

            
        });

        JButton delete = new JButton("Delete"); // delete the selected shape
        delete.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // to do
                
            }

            
        });

        JButton move = new JButton("Move"); // move the selected shape
        move.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // to do
                
            }

            
        });

        JButton merge = new JButton("Merge"); // merge graphs together
        merge.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // to do
                
            }

            
        });

        JButton copy = new JButton("Copy"); // copy existing graphs
        copy.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                // to do
                
            }

            
        });

        




        // need to change the entire drawing situation to drag

        container.addMouseListener(new MouseListener(){

            @Override
            public void mouseClicked(MouseEvent e) {
                
                
            }

            @Override
            public void mousePressed(MouseEvent e) {
                
            
            }

            @Override
            public void mouseReleased(MouseEvent e) {

                if (status == "Rectangle") {
                    
                    Rectangle new_rectangle = new Rectangle(e.getX(), e.getY(), c, width, height);
                    shapes.add(new_rectangle); 
                    
                } else if (status == "Circle") {

                    Circle new_Circle = new Circle(e.getX(), e.getY(), c, width, height); 
                    shapes.add(new_Circle);

                }

                frame.getContentPane().repaint();


                
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                // TODO Auto-generated method stub
                
            }

            @Override
            public void mouseExited(MouseEvent e) {
                // TODO Auto-generated method stub
                
            }

        });
      

        containerButton1.add(rectangleButton);
        containerButton1.add(circleButton);
        containerButton1.add(line);
        containerButton1.add(text); 
        containerButton1.add(polygon);

        containerButton1.setPreferredSize(new Dimension(WIDTH, BUTTONHEIGHT));

        utilityPanel.add(clear);
        utilityPanel.add(undo);
        utilityPanel.add(choosingColor);
        utilityPanel.add(delete); 
        utilityPanel.add(merge);
        utilityPanel.add(move);
        utilityPanel.add(copy);

        utilityPanel.setPreferredSize(new Dimension(WIDTH, BUTTONHEIGHT));

        container.add(canvas); 
        container.add(containerButton1);
        container.add(utilityPanel);
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));
        
        frame.add(container);
        frame.setVisible(true);

        

    }

    public static void main (String[] args) {
        new graphicsFinal().startGraphics();
    }

}


