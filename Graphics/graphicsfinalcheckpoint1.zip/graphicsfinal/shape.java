package graphicsfinal;
import java.awt.*;

public abstract class shape {

    int x;
    int y;
    int width;
    int height;
    Color c;
    

    public shape(int x, int y, Color c, int w, int h) {

        this.x = x;
        this.y = y; 
        this.c = c;
        width = w;
        height = h;      

    }

    abstract public void draw(Graphics g);
    
}
