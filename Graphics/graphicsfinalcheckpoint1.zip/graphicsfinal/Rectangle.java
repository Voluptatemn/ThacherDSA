package graphicsfinal;
import java.awt.*;


public class Rectangle extends shape{

    public Rectangle(int x, int y, Color c, int w, int h) {
        super(x, y, c, w, h);
    }

    @Override
    public void draw(Graphics g) {
    
        g.setColor(c);
        g.fillRect(x, y, width, height);
        
    }
    
}
