package graphicsfinal;

import java.awt.Color;
import java.awt.Graphics;

public class Line extends shape{

    public Line(int x, int y, Color c, int w, int h) {
        super(x, y, c, w, h);
        //TODO Auto-generated constructor stub
    }

    @Override
    public void draw(Graphics g) {
        // TODO Auto-generated method stub
        g.setColor(c);
        g.drawLine(x, y, x, y);
        
    }
    
}
