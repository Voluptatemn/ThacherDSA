package graphicsfinal;

import java.awt.Color;
import java.awt.Graphics;

public class Circle extends shape{

    public Circle(int x, int y, Color c, int w, int h) {
        super(x, y, c, w, h);
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(c);
        g.fillOval(x, y, width, height);
        
    }
    
    
}
